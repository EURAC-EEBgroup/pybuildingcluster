=======
History
=======

0.0.1 (2025-06-26)
------------------

* First release on PyPI.

0.0.5 (2025-06-26)
------------------

* Modifying authors and readme file